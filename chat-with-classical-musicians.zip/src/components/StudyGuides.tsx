import { useState } from 'react';
import { 
  FileText, Sparkles, Printer, Check, BookOpen, Volume2
} from 'lucide-react';
import { musicians } from '../data/composers';
import { playNote } from '../utils/audioSynth';

interface PianoKey {
  note: string;
  isBlack: boolean;
  label: string;
}

const PIANO_KEYS: PianoKey[] = [
  { note: 'C4', isBlack: false, label: '도' },
  { note: 'C#4', isBlack: true, label: '도#' },
  { note: 'D4', isBlack: false, label: '레' },
  { note: 'D#4', isBlack: true, label: '레#' },
  { note: 'E4', isBlack: false, label: '미' },
  { note: 'F4', isBlack: false, label: '파' },
  { note: 'F#4', isBlack: true, label: '파#' },
  { note: 'G4', isBlack: false, label: '솔' },
  { note: 'G#4', isBlack: true, label: '솔#' },
  { note: 'A4', isBlack: false, label: '라' },
  { note: 'A#4', isBlack: true, label: '라#' },
  { note: 'B4', isBlack: false, label: '시' },
  { note: 'C5', isBlack: false, label: '도' },
  { note: 'C#5', isBlack: true, label: '도#' },
  { note: 'D5', isBlack: false, label: '레' },
  { note: 'D#5', isBlack: true, label: '레#' },
  { note: 'E5', isBlack: false, label: '미' },
  { note: 'F5', isBlack: false, label: '파' },
  { note: 'F#5', isBlack: true, label: '파#' },
  { note: 'G5', isBlack: false, label: '솔' },
  { note: 'G#5', isBlack: true, label: '솔#' },
  { note: 'A5', isBlack: false, label: '라' },
  { note: 'A#5', isBlack: true, label: '라#' },
  { note: 'B5', isBlack: false, label: '시' },
  { note: 'C6', isBlack: false, label: '도' }
];

interface PlayAlongSong {
  title: string;
  notes: string[];
  description: string;
  photo: string;
}

const SONGS: PlayAlongSong[] = [
  {
    title: '반짝반짝 작은 별 (모차르트)',
    notes: ['C4', 'C4', 'G4', 'G4', 'A4', 'A4', 'G4', 'F4', 'F4', 'E4', 'E4', 'D4', 'D4', 'C4'],
    description: '모차르트가 편곡한 유명한 프랑스 민요예요.',
    photo: '/images/mozart.jpg'
  },
  {
    title: '환희의 송가 (베토벤)',
    notes: ['E4', 'E4', 'F4', 'G4', 'G4', 'F4', 'E4', 'D4', 'C4', 'C4', 'D4', 'E4', 'E4', 'D4', 'D4'],
    description: '베토벤의 교향곡 9번 합창에 나오는 감동적인 멜로디예요.',
    photo: '/images/beethoven.jpg'
  },
  {
    title: '미뉴에트 G장조 (바흐)',
    notes: ['D5', 'G4', 'A4', 'B4', 'C5', 'D5', 'G4', 'G4', 'E5', 'C5', 'D5', 'E5', 'F#5', 'G5', 'G4'],
    description: '바흐 집안의 다정하고 경쾌한 춤곡 멜로디예요.',
    photo: '/images/bach.jpg'
  }
];

export default function StudyGuides() {
  const allComposers = Object.values(musicians);
  
  // States
  const [subTab, setSubTab] = useState<'cards' | 'piano' | 'worksheets'>('cards');
  const [selectedComposerName, setSelectedComposerName] = useState<string>(allComposers[0].name);
  
  // Piano state
  const [waveType, setWaveType] = useState<OscillatorType>('sine');
  const [activeNote, setActiveNote] = useState<string | null>(null);
  
  // Play Along Song state
  const [selectedSong, setSelectedSong] = useState<PlayAlongSong | null>(null);
  const [songStep, setSongStep] = useState<number>(0);
  const [hasCopiedWorksheet, setHasCopiedWorksheet] = useState(false);

  const selectedComposer = musicians[selectedComposerName];

  const handleKeyClick = (note: string) => {
    setActiveNote(note);
    playNote(note, waveType, 0.4);
    
    // Check if matching play-along step
    if (selectedSong && note === selectedSong.notes[songStep]) {
      const nextStep = songStep + 1;
      if (nextStep >= selectedSong.notes.length) {
        // finished
        setSongStep(0);
        setTimeout(() => {
          // Play a small congratulations scale
          playNote('C5', 'sine', 0.1);
          setTimeout(() => playNote('E5', 'sine', 0.1), 100);
          setTimeout(() => playNote('G5', 'sine', 0.1), 200);
          setTimeout(() => playNote('C6', 'sine', 0.3), 300);
          alert('🎉 대단해요! 노래를 끝까지 완벽하게 연주하셨습니다!');
        }, 300);
      } else {
        setSongStep(nextStep);
      }
    } else if (selectedSong) {
      // wrong note resets step or does nothing (we'll just let them retry the same step)
    }

    setTimeout(() => {
      setActiveNote(null);
    }, 400);
  };

  const handleStartSong = (song: PlayAlongSong) => {
    setSelectedSong(song);
    setSongStep(0);
    playNote('C5', 'sine', 0.2);
  };

  const handleCopyWorksheet = () => {
    const text = `
[초등 음악 감상 보고서]

학번: __________  이름: __________

1. 내가 조사한 음악가: ${selectedComposer.name}
2. 음악가의 별명: ${selectedComposer.nickname}
3. 음악가가 살았던 시대: ${selectedComposer.era}
4. 음악가의 대표곡: ${selectedComposer.famousSongs.join(', ')}
5. 시대적 특징 한 줄 요약: ${selectedComposer.eraInfo}
6. 가장 인상 깊었던 이야기: ${selectedComposer.funStory}
    `;
    navigator.clipboard.writeText(text);
    setHasCopiedWorksheet(true);
    setTimeout(() => setHasCopiedWorksheet(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto bg-amber-50/20 rounded-3xl border-4 border-amber-900/60 p-6 shadow-xl space-y-6">
      {/* Tab Header Selector */}
      <div className="flex flex-col md:flex-row justify-between items-center border-b border-amber-900/10 pb-4 gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-amber-950 flex items-center gap-2">
            <BookOpen className="w-8 h-8 text-amber-700" />
            초등 음악 학습 도서관 🏫
          </h2>
          <p className="text-amber-800 text-xs md:text-sm mt-1">
            혼자서도 재미있게 공부할 수 있는 감상 요약 카드, 개인 활동지, 미니 피아노 연습장을 제공해요.
          </p>
        </div>

        {/* Sub-tabs buttons */}
        <div className="flex bg-amber-900/10 p-1 rounded-xl border border-amber-900/5 select-none">
          <button
            onClick={() => { setSubTab('cards'); playNote('C5', 'sine', 0.1); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              subTab === 'cards' ? 'bg-amber-900 text-white shadow-sm' : 'text-amber-900/70 hover:bg-amber-900/5'
            }`}
          >
            📋 음악가 요약 카드
          </button>
          <button
            onClick={() => { setSubTab('piano'); playNote('E5', 'sine', 0.1); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              subTab === 'piano' ? 'bg-amber-900 text-white shadow-sm' : 'text-amber-900/70 hover:bg-amber-900/5'
            }`}
          >
            🎹 미니 피아노 교실
          </button>
          <button
            onClick={() => { setSubTab('worksheets'); playNote('G5', 'sine', 0.1); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              subTab === 'worksheets' ? 'bg-amber-900 text-white shadow-sm' : 'text-amber-900/70 hover:bg-amber-900/5'
            }`}
          >
            📄 나의 음악 학습지
          </button>
        </div>
      </div>

      {/* SUBTAB 1: Summary Cards */}
      {subTab === 'cards' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* List panel */}
          <div className="md:col-span-4 bg-white/80 border border-amber-900/10 rounded-2xl p-4 shadow-sm space-y-2 max-h-[400px] overflow-y-auto">
            <h3 className="text-xs font-bold text-amber-900 mb-2">음악가 목록</h3>
            {allComposers.map((comp) => (
              <button
                key={comp.id}
                onClick={() => {
                  setSelectedComposerName(comp.name);
                  playNote('C5', 'sine', 0.1);
                }}
                className={`w-full flex items-center gap-3 p-2 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedComposerName === comp.name
                    ? 'bg-amber-900 border-amber-950 text-white'
                    : 'bg-white hover:bg-amber-50 text-amber-950 border-amber-800/10'
                }`}
              >
                <img
                  src={comp.photo}
                  alt={comp.name}
                  className="w-10 h-10 rounded-full object-cover border"
                />
                <div>
                  <h4 className="font-bold text-xs md:text-sm">{comp.name}</h4>
                  <p className={`text-[10px] ${selectedComposerName === comp.name ? 'text-amber-300' : 'text-amber-700'}`}>
                    {comp.era}
                  </p>
                </div>
              </button>
            ))}
          </div>

          {/* Details Card */}
          {selectedComposer && (
            <div className="md:col-span-8 bg-white/90 border-2 border-amber-400 rounded-3xl p-6 shadow-md flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                {/* Header */}
                <div className="flex items-center gap-3 border-b border-amber-100 pb-3">
                  <img
                    src={selectedComposer.photo}
                    alt={selectedComposer.name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-amber-400"
                  />
                  <div>
                    <h3 className="text-xl font-bold text-amber-950 flex items-center gap-2">
                      {selectedComposer.name}
                      <span className="text-xs bg-amber-100 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full font-normal">
                        {selectedComposer.era}
                      </span>
                    </h3>
                    <p className="text-xs text-amber-700 font-semibold">{selectedComposer.nickname}</p>
                  </div>
                </div>

                {/* Grid details */}
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div className="bg-amber-50/50 p-3 rounded-xl border border-amber-900/5">
                    <p className="font-bold text-amber-900 mb-1">🌍 태어난 나라</p>
                    <p className="text-amber-950">{selectedComposer.country}</p>
                  </div>
                  <div className="bg-amber-50/50 p-3 rounded-xl border border-amber-900/5">
                    <p className="font-bold text-amber-900 mb-1">🎵 대표작 목록</p>
                    <p className="text-amber-950 truncate" title={selectedComposer.famousSongs.join(', ')}>
                      {selectedComposer.famousSongs.join(', ')}
                    </p>
                  </div>
                </div>

                {/* Style & Fun Story */}
                <div className="space-y-2 text-xs md:text-sm">
                  <div>
                    <span className="font-bold text-amber-900 block mb-1">🎼 음악적 스타일</span>
                    <p className="text-amber-950 leading-relaxed bg-white border border-amber-800/10 p-3 rounded-xl">
                      {selectedComposer.style}
                    </p>
                  </div>
                  <div>
                    <span className="font-bold text-amber-900 block mb-1">💡 재미있는 이야기 (에피소드)</span>
                    <p className="text-amber-950 leading-relaxed bg-white border border-amber-800/10 p-3 rounded-xl">
                      {selectedComposer.funStory}
                    </p>
                  </div>
                </div>

              </div>

              {/* Action row */}
              <div className="flex gap-2 justify-end">
                <button
                  onClick={handleCopyWorksheet}
                  className="flex items-center gap-1 px-4 py-2 bg-amber-100 hover:bg-amber-200 border border-amber-900/20 text-amber-950 text-xs font-bold rounded-lg cursor-pointer transition-colors"
                >
                  {hasCopiedWorksheet ? <Check className="w-4 h-4 text-green-700" /> : <FileText className="w-4 h-4" />}
                  {hasCopiedWorksheet ? '복사 완료!' : '활동지 텍스트 복사'}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 2: Interactive Piano */}
      {subTab === 'piano' && (
        <div className="space-y-6">
          {/* Instructions and Wave selector */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-white/80 border border-amber-900/10 rounded-2xl p-4 gap-4">
            <div>
              <h3 className="font-bold text-amber-950 text-sm md:text-base flex items-center gap-1.5">
                <Volume2 className="w-4.5 h-4.5 text-amber-700" />
                마우스 클릭이나 터치로 피아노 건반을 짚어보세요!
              </h3>
              <p className="text-xs text-amber-800/80">
                Web Audio API로 실시간 합성되는 2옥타브 전자 오르간 사운드입니다.
              </p>
            </div>

            {/* Synthesizer voice select */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-900">음색 종류:</span>
              <div className="flex bg-amber-100 rounded-lg p-0.5 border border-amber-200">
                {(['sine', 'triangle', 'square', 'sawtooth'] as OscillatorType[]).map((type) => (
                  <button
                    key={type}
                    onClick={() => {
                      setWaveType(type);
                      playNote('C5', type, 0.2);
                    }}
                    className={`px-2 py-1 rounded text-[10px] font-bold transition-all cursor-pointer capitalize ${
                      waveType === type ? 'bg-amber-950 text-white' : 'text-amber-900/70 hover:bg-amber-200'
                    }`}
                  >
                    {type === 'sine' ? '부드러움' : type === 'triangle' ? '오르간' : type === 'square' ? '게임음' : '바이올린'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Songs to Play Along */}
          <div className="bg-white/80 border border-amber-900/10 rounded-2xl p-4">
            <h4 className="text-xs font-bold text-amber-950 mb-2 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-300" />
              따라 연주해보기 모드:
            </h4>
            <div className="flex flex-wrap gap-2">
              {SONGS.map((song, idx) => (
                <button
                  key={idx}
                  onClick={() => handleStartSong(song)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                    selectedSong?.title === song.title
                      ? 'bg-amber-900 text-white border-amber-950 shadow-sm'
                      : 'bg-white hover:bg-amber-50 text-amber-900 border-amber-800/20'
                  }`}
                >
                  {song.title}
                </button>
              ))}
            </div>

            {/* Song play along guide */}
            {selectedSong && (
              <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-xl">
                 <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-amber-900">{selectedSong.title} 연주 가이드</span>
                  <button
                    onClick={() => { setSelectedSong(null); setSongStep(0); }}
                    className="text-[10px] text-amber-600 hover:text-amber-800 underline font-semibold"
                  >
                    가이드 끄기
                  </button>
                </div>
                <div className="flex items-center gap-3 mb-3 bg-white/60 p-2 rounded-lg border border-amber-900/10">
                  <img
                    src={selectedSong.photo}
                    alt={selectedSong.title}
                    className="w-12 h-12 rounded-full object-cover border border-amber-300"
                  />
                  <p className="text-[11px] text-amber-850 font-medium leading-relaxed">{selectedSong.description}</p>
                </div>
                
                {/* Notes track bar */}
                <div className="flex flex-wrap gap-1.5 items-center">
                  {selectedSong.notes.map((note, idx) => {
                    const isPassed = idx < songStep;
                    const isCurrent = idx === songStep;
                    return (
                      <div
                        key={idx}
                        className={`text-xs px-2 py-1 rounded font-bold border transition-all ${
                          isCurrent
                            ? 'bg-amber-400 border-amber-900 text-amber-950 scale-110 shadow-glow font-black'
                            : isPassed
                            ? 'bg-green-100 border-green-300 text-green-700 opacity-60'
                            : 'bg-white border-amber-200 text-amber-900/60'
                        }`}
                      >
                        {note}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Interactive Keyboard UI */}
          <div className="relative bg-amber-950/90 rounded-2xl p-6 border-4 border-amber-900 select-none overflow-x-auto min-w-[500px]">
            {/* Keyboard Guide */}
            {selectedSong && (
              <div className="text-center text-xs font-bold text-amber-300 mb-4 animate-pulse">
                👉 아래 키보드에서 주황색으로 표시된 건반({selectedSong.notes[songStep]})을 누르세요!
              </div>
            )}

            {/* Keys frame */}
            <div className="relative flex justify-center h-48 bg-amber-950 pb-2">
              {PIANO_KEYS.map((key) => {
                // Determine if key is white or black
                // Black keys should hover on top of white keys absolute
                const isSelectedToPlay = selectedSong && key.note === selectedSong.notes[songStep];
                const isActive = activeNote === key.note;

                if (key.isBlack) return null; // We render white keys first, then overlay black keys

                // Calculate black key sibling offset to place on top
                const selfIdx = PIANO_KEYS.findIndex((pk) => pk.note === key.note);
                const nextKey = PIANO_KEYS[selfIdx + 1];
                const hasBlackNext = nextKey && nextKey.isBlack;

                return (
                  <div key={key.note} className="relative flex">
                    {/* White Key */}
                    <button
                      onClick={() => handleKeyClick(key.note)}
                      className={`w-12 h-44 rounded-b-lg border-x border-b border-amber-900/40 transition-all flex flex-col justify-end pb-3 items-center text-[10px] font-bold cursor-pointer ${
                        isActive
                          ? 'bg-amber-200 shadow-inner translate-y-1'
                          : isSelectedToPlay
                          ? 'bg-amber-300 border-2 border-amber-900'
                          : 'bg-white hover:bg-amber-50 text-amber-950'
                      }`}
                    >
                      <span>{key.label}</span>
                      <span className="text-[8px] opacity-50 mt-1">{key.note}</span>
                    </button>

                    {/* Black Key Overlay */}
                    {hasBlackNext && (
                      <button
                        onClick={() => handleKeyClick(nextKey.note)}
                        className={`absolute left-8 w-8 h-28 bg-black rounded-b border border-amber-900 transition-all z-10 flex flex-col justify-end pb-2 items-center text-[8px] font-bold cursor-pointer ${
                          activeNote === nextKey.note
                            ? 'bg-amber-200 text-amber-950 translate-y-1'
                            : selectedSong && nextKey.note === selectedSong.notes[songStep]
                            ? 'bg-amber-400 text-amber-950'
                            : 'text-white hover:bg-neutral-800'
                        }`}
                      >
                        <span>{nextKey.label}</span>
                        <span className="opacity-60 scale-75 mt-0.5">{nextKey.note}</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: Teacher Activity sheets / Lesson Plan */}
      {subTab === 'worksheets' && (
        <div className="space-y-6">
          {/* Printable Worksheet Preview Container */}
          <div className="bg-white/95 border-2 border-amber-900/20 rounded-2xl p-6 shadow-sm space-y-6 max-h-[500px] overflow-y-auto">
            {/* Header info */}
            <div className="flex justify-between items-center border-b pb-3 select-none">
              <span className="text-xs text-amber-800 font-bold bg-amber-100 px-2 py-0.5 rounded">활동지 템플릿</span>
              <button 
                onClick={() => window.print()}
                className="flex items-center gap-1 text-xs text-amber-900 bg-amber-100 hover:bg-amber-200 border border-amber-200 px-2.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" /> 화면 인쇄하기
              </button>
            </div>

            {/* Document layout */}
            <div className="space-y-6 border border-neutral-200 p-6 rounded-xl bg-white text-black font-sans leading-relaxed">
              <div className="text-center border-b-2 border-black pb-4">
                <h3 className="text-2xl font-black tracking-tight">클래식 음악가 탐구 학습지</h3>
                <p className="text-xs text-neutral-600 mt-1">시대별 음악가의 삶과 음악을 체험하고 느낌을 기록해 보세요.</p>
              </div>

              {/* Class/Name fields */}
              <div className="grid grid-cols-3 gap-4 text-sm border-b pb-4">
                <div>학년 반: _____________</div>
                <div>번호: _____________</div>
                <div>이름: _____________</div>
              </div>

              {/* Content items */}
              <div className="space-y-4 text-xs md:text-sm">
                <div>
                  <h4 className="font-extrabold mb-1">1. 내가 선택한 음악가에 대한 기본 정보를 기록하세요.</h4>
                  <div className="grid grid-cols-2 gap-3 border p-3 rounded bg-neutral-50/50">
                    <div>음악가 이름: _________________</div>
                    <div>활동한 시대: _________________</div>
                    <div>출신 국가: _________________</div>
                    <div>대표적 별명: _________________</div>
                  </div>
                </div>

                <div>
                  <h4 className="font-extrabold mb-1">2. 해당 음악가가 활동했던 '시대'는 어떤 음악적 특징을 가졌나요?</h4>
                  <p className="text-neutral-500 border p-3 rounded h-20">
                    (예: 바로크 시대는 화려하고 웅장한 대위법 음악이 많았어요...)
                  </p>
                </div>

                <div>
                  <h4 className="font-extrabold mb-1">3. 음악가의 대표곡 중 하나를 골라 시그니처 멜로디를 감상하고, 어떤 느낌(빠르기, 악기, 분위기 등)을 받았는지 적어보세요.</h4>
                  <div className="border p-3 rounded space-y-2">
                    <p className="font-bold text-xs text-neutral-800">감상곡 제목: _________________________________________</p>
                    <p className="text-neutral-500 h-24 pt-2 border-t">
                      (느낀 점 기록란)
                    </p>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </div>
      )}
    </div>
  );
}
